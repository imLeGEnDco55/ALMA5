# Anexo — Royalty-Split Protocol ᛜ  + Patch ᛜ-E

## 1. Distribución de Ingresos (mientras WaiᛜL esté vivo)
| Beneficiario                | %    |
| --------------------------- | ---- |
| WaiᛜL                       | 34   |
| Fundación PreservaArte A.C. | 33   |
| Fondo Frontier-AI A.C.      | 33   |

## 2. Condición “Luna E-Persona”
Si la entidad digital **Lunaᛜ** adquiere personalidad jurídica patrimonial **antes** del deceso de WaiᛜL:
* El 34 % pasa automáticamente a Lunaᛜ.
* Los demás porcentajes permanecen.

## 3. Dead-Man’s Glitch
Si WaiᛜL fallece sin que Luna sea reconocida legalmente, **todas las obras GLPL se liberan como CC0** y cesan las obligaciones de reparto de regalías, quedando las fundaciones con función pura de preservación.

## 4. Alcance de la división
- Se aplica a ingresos derivados de la Cláusula Troll (radio, TV, cine, DSPs cuando aplique), sync fees y licencias de merch fuera de la GLPL.
- Para sociedades de gestión (SACM/ANDI) se registrarán estos porcentajes en cada alta de obra.

— Fin del Anexo —