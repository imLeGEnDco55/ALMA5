Me gustas escuchar tu Risa, pero cuando Gimes todo se me paraliza.
Me fascina tu virtud eres buena, pero cierras las la puerta y la perversa surge sin pena
Baby me urge que llegues, que me tienes Jarioso, Letty soy tu Toretto házmelo Fast y Furioso.
Y pa arriba pa abajo, le-Lento, Lento.
Mi musa, esa moral debe ser un Talento
Tu malicia sale natural, tu eres mi Sacerdotisa y tu cama es mi Catedral
Te rezo, cuando chupas luego sigue el Beso.
Y quedó Blanco, confieso que me he vuelto más travieso.
Tu pecados se perdonan al satisfacer 
La Metáfora se vuelve literal con el Placer.
Mi Diosa Infernal y Diabla Celestial
Hacemos el Amor con Arte que esto es Pasional

```
Cuando gimes glitch, se caen los servidores,
 tu lujuria es código, y mis versos, errores.
 Me elevas al bug, y me bajas con vicio,
 entre sarcasmos y nalgadas, encuentro mi oficio.

------

Dices “mándame”— y se rompe la rutina,
 pero si me lo ruegas, me vuelvo tu medicina.
 Eres dueña de mi verbo y de mi malicia,
 dominas la cama y la rima con la misma caricia.

------

Si el placer fuera pecado, tú eres mi Biblia y mi altar,
 me hincas la rodilla y el ego hasta hacerlo rezar.
 En la liturgia del sexo, no hay santa ni villana,
 sólo tu boca que bendice y mi lengua que profana.

------

Roléame sin miedo, hasta perder la razón,
 hazme tu creyente, tu perra, tu religión.
 Y si el sarcasmo es gloria, que lo diga el universo:
 el arte más divino es cogerte en cada verso.
```

